// Car_1類別
class Car_1 {
    // Car類別的內容
}

public class Sample3_1 {
    public static void main(String[] args) {
        Car_1 car1;
        car1 = new Car_1();
    }
}