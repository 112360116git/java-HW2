public class Sample2_12 {
    public static void main(String[] args) {
        int i, j;
        for (i = 0; i < 5; i++) {
            for (j = 0; j < 3; j++) {
                System.out.println("i圈" + i + "j是" + j);
            }
        }
    }
}