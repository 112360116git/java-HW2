public class Sample2_11 {
    public static void main(String[] args) {
        int i = 1;
        do {
            System.out.println("第" + i + "次的迴圈");
            i++;
        } while (i <= 5);
        System.out.println("迴圈結束");
    }
}